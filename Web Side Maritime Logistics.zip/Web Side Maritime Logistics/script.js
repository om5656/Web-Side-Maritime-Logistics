window.onload = function() {
  setTimeout(function() {
    document.getElementById("title").textContent = "Hello";
  }, 2000); 
};